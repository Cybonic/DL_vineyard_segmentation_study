import pathlib
import os
import sys 
path  = os.path.dirname(pathlib.Path(__file__).parent.absolute())
sys.path.append(path)